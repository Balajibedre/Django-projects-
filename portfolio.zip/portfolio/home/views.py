from django.shortcuts import render, HttpResponse

# Create your views here.
def home(request):
    #return HttpResponse("This is my homepage (/)")
    #context = {'name': 'Nitin', 'course': 'Django'}
    context = {'name': 'Rutuja', 'course': 'Python'}
    return render(request, 'home.html', context)

def about(request):
    #return HttpResponse("This is my about page (/about)")
    return render(request, 'about.html')

def socialwork(request):
    #return HttpResponse("This is my projects page (/socialwork)")
    return render(request, 'socialwork.html')

def contact(request):
    #return HttpResponse("This is my contact page (/contact)")
    return render(request, 'contact.html')

def adventures(request):
    #return HttpResponse("This is my contact page (/adventures)")
    return render(request, 'adventures.html')